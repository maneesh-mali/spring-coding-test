package com.db.dataplatform.techtest.client.component.impl;

import com.db.dataplatform.techtest.client.api.model.DataEnvelope;
import com.db.dataplatform.techtest.client.api.model.DataHeader;
import com.db.dataplatform.techtest.client.component.Client;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * Client code does not require any test coverage
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class ClientImpl implements Client {

    public static final String URI_PUSHDATA = "http://localhost:8090/dataserver/pushdata";
    public static final UriTemplate URI_GETDATA = new UriTemplate("http://localhost:8090/dataserver/data/{blockType}");
    public static final UriTemplate URI_PATCHDATA = new UriTemplate("http://localhost:8090/dataserver/update/{name}/{newBlockType}");

    @Autowired
    private RestTemplate clientRestTemplate;

    @Override
    public void pushData(DataEnvelope dataEnvelope) {
        log.info("Pushing data {} to {}", dataEnvelope.getDataHeader().getName(), URI_PUSHDATA);

        try {
            ResponseEntity<Boolean> response = clientRestTemplate.postForEntity(URI_PUSHDATA, dataEnvelope, Boolean.class);
            log.info("Pushing data {} to {} retuned HTTP status {} with server response {}",
                    dataEnvelope.getDataHeader().getName(), URI_PUSHDATA,
                    response.getStatusCode(), response.getBody());

        } catch (RestClientException  restClientException) {
            log.error("Pushing data failed with exception", restClientException);
        }

    }

    @Override
    public List<DataEnvelope> getData(String blockType) {
        log.info("Query for data with header block type {}", blockType);
        List<DataEnvelope> list = new ArrayList<DataEnvelope>();
        try {
            list = clientRestTemplate.exchange(URI_GETDATA.expand(blockType).toString(),
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<DataEnvelope>>() {
                    }).getBody();
        } catch (RestClientException restClientException) {
            log.error("get data failed with exception", restClientException);
        }

        return list;

    }

    @Override
    public boolean updateData(String blockName, BlockTypeEnum newBlockType) {
        log.info("Updating blocktype to {} for block with name {}", newBlockType, blockName);
        DataHeader dataHeader = new DataHeader("blockName", newBlockType);
        Boolean response = false;

        try {
            response = clientRestTemplate.patchForObject(URI_PATCHDATA.expand(blockName, newBlockType.name()).toString(), dataHeader, Boolean.class);
        } catch (RestClientException restClientException) {
            log.error("get data failed with exception", restClientException);
        }

        return response;
    }


}
