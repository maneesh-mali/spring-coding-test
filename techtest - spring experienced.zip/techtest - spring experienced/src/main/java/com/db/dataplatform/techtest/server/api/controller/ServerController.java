package com.db.dataplatform.techtest.server.api.controller;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.exception.BlockNotFoundException;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.util.List;
import java.util.concurrent.Callable;

@Slf4j
@Controller
@RequestMapping("/dataserver")
@RequiredArgsConstructor
@Validated
public class ServerController {

    private final Server server;

    @PostMapping(value = "/pushdata", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Callable<ResponseEntity<Boolean>> pushData(@Valid @RequestBody DataEnvelope dataEnvelope) {

        log.info("Data envelope received: {}", dataEnvelope.getDataHeader().getName());

        Callable<ResponseEntity<Boolean>> response = () -> {
            server.saveDataEnvelope(dataEnvelope);
            return ResponseEntity.ok(true);
        };

        return response;
    }

    @GetMapping(value = "/data/{blockType}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DataEnvelope>> getData(@Valid @PathVariable("blockType") String blockType,
                                                      @RequestParam(defaultValue = "0") Integer pageNo,
                                                      @RequestParam(defaultValue = "10") Integer pageSize) throws IllegalArgumentException {
        log.info("Retrieving blocks by blockType: {}", blockType);

        List<DataEnvelope> results = server.getDataBlocksByType(blockType, pageNo, pageSize);

        log.info("Retrieved {} blocks by blockType: {}", results.size(), blockType);
        return ResponseEntity.ok(results);
    }


    @PatchMapping(value = "/update/{name}/{blockType}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Boolean> updateData(@PathVariable("name") @Pattern(regexp = "[A-Z]{4}-[A-Z]{6}-[0-9]{2}[A-Z]") String name,
                                              @PathVariable("blockType") String blockType) throws BlockNotFoundException {

        log.info("Update block {} with blockType {}", name, blockType);
        boolean result = server.updateBlockType(name, BlockTypeEnum.valueOf(blockType));
        return ResponseEntity.ok(result);

    }

}
