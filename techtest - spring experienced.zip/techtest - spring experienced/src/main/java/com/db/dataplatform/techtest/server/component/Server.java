package com.db.dataplatform.techtest.server.component;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.exception.BlockNotFoundException;
import com.db.dataplatform.techtest.server.exception.ChecksumFailureException;
import com.db.dataplatform.techtest.server.exception.HadoopClientException;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface Server {
    void saveDataEnvelope(DataEnvelope envelope) throws IOException, NoSuchAlgorithmException, HadoopClientException, ChecksumFailureException;
    List<DataEnvelope> getDataBlocksByType(String blockType, Integer pageNo, Integer pageSize) throws IllegalArgumentException;

    boolean updateBlockType(String blockName, BlockTypeEnum blockType) throws BlockNotFoundException;
}
