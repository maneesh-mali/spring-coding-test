package com.db.dataplatform.techtest.server.exception;

public class BlockNotFoundException extends Exception {

    BlockNotFoundException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public BlockNotFoundException(final String message) {
        super(message);
    }
}
