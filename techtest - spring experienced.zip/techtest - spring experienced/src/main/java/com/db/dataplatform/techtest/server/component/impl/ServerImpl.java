package com.db.dataplatform.techtest.server.component.impl;

import com.db.dataplatform.techtest.server.api.model.DataBody;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.api.model.DataHeader;
import com.db.dataplatform.techtest.server.exception.BlockNotFoundException;
import com.db.dataplatform.techtest.server.exception.ChecksumFailureException;
import com.db.dataplatform.techtest.server.exception.HadoopClientException;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import com.db.dataplatform.techtest.server.component.Server;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ServerImpl implements Server {

    private static final String CHECKSUM_ALGORITHM = "MD5";
    public static final String HADOOP_URI_PUSHDATA = "http://localhost:8090/hadoopserver/pushbigdata";

    private final DataBodyService dataBodyServiceImpl;
    private final ModelMapper modelMapper;

    @Autowired
    private final RestTemplate serverRestTemplate;

    /**
     * @param envelope
     * @return true if there is a match with the client provided checksum.
     */
    @Override
    @Transactional(rollbackFor = HadoopClientException.class)
    public void saveDataEnvelope(DataEnvelope envelope) throws NoSuchAlgorithmException, HadoopClientException, ChecksumFailureException {

        log.info("saveDataEnvelope : {}", envelope.getDataHeader().getName());

        //validate checksum
        validateCheckSum(envelope);

        // Save to persistence.
        persist(envelope);

        // push data to hadoop
        pushDataToHadoop(envelope);

    }


    @Override
    public List<DataEnvelope> getDataBlocksByType(String blockType, Integer pageNo, Integer pageSize) throws IllegalArgumentException {
        log.info("Getting blocks by Type : {}", blockType);

        BlockTypeEnum blockTypeEnum = BlockTypeEnum.valueOf(blockType);
        Pageable paging = PageRequest.of(pageNo,pageSize);
        List<DataBodyEntity> list = dataBodyServiceImpl.getDataByBlockType(blockTypeEnum, paging);

        return list.stream().map(
                item -> new DataEnvelope(
                        modelMapper.map(item.getDataHeaderEntity(), DataHeader.class),
                        modelMapper.map(item, DataBody.class)
                )).collect(Collectors.toList());

    }

    @Override
    public boolean updateBlockType(String name, BlockTypeEnum blockType) throws BlockNotFoundException {

        Optional<DataBodyEntity> dataBodyEntityOptional = dataBodyServiceImpl.getDataByBlockName(name);

        if (dataBodyEntityOptional.isPresent()) {

            DataBodyEntity dataBodyEntity = dataBodyEntityOptional.get();
            dataBodyEntity.getDataHeaderEntity().setBlocktype(blockType);
            saveData(dataBodyEntity);

        } else {
            log.info("Block name {} not found", name);
            throw new BlockNotFoundException("Block name "+ name +" not found");
        }

        return true;
    }

    private void persist(DataEnvelope envelope) {
        log.info("Persisting data with attribute name: {}", envelope.getDataHeader().getName());
        DataHeaderEntity dataHeaderEntity = modelMapper.map(envelope.getDataHeader(), DataHeaderEntity.class);

        DataBodyEntity dataBodyEntity = modelMapper.map(envelope.getDataBody(), DataBodyEntity.class);
        dataBodyEntity.setDataHeaderEntity(dataHeaderEntity);

        saveData(dataBodyEntity);
    }

    private void saveData(DataBodyEntity dataBodyEntity) {
        dataBodyServiceImpl.saveDataBody(dataBodyEntity);
    }

    private boolean validateCheckSum(DataEnvelope dataEnvelope) throws NoSuchAlgorithmException, ChecksumFailureException {

        MessageDigest messageDigest = MessageDigest.getInstance(CHECKSUM_ALGORITHM);
        messageDigest.update(dataEnvelope.getDataBody().getDataBody().getBytes());
        byte[] digest = messageDigest.digest();

        String hash = DatatypeConverter.printHexBinary(digest).toUpperCase();
        String clientHash = dataEnvelope.getDataBody().getMd5CheckSum().toUpperCase();

        if (clientHash.equals(hash)) {
            log.info("MD5 check sum validation passed for {} ",dataEnvelope.getDataHeader().getName());
        } else {
            log.error("MD5 check sum validation failed for {} ",dataEnvelope.getDataHeader().getName());
            throw new ChecksumFailureException("Check sum validation failed using " + CHECKSUM_ALGORITHM);
        }
        return true;
    }

    private void pushDataToHadoop(DataEnvelope envelope) throws HadoopClientException {
        // Push to hadoop
        try {
            ResponseEntity<String> hadoopResponse = serverRestTemplate.postForEntity(HADOOP_URI_PUSHDATA, envelope, String.class);

            if (HttpStatus.OK != hadoopResponse.getStatusCode()) {
                log.info("Hadoop service response code received {}", hadoopResponse.getStatusCode().toString());
                throw new HadoopClientException("Failure storing data into hadoop for block name "+ envelope.getDataHeader().getName());
            }

        } catch (RestClientException restClientException) {
            log.info("Hadoop service rest exception", restClientException);
            throw new HadoopClientException(restClientException.getMessage());

        }
    }

}
