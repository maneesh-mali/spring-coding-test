package com.db.dataplatform.techtest.server.exception;

public class ChecksumFailureException extends Exception {

    ChecksumFailureException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public ChecksumFailureException(final String message) {
        super(message);
    }
}
