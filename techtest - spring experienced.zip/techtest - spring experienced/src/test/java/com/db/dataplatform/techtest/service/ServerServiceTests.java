package com.db.dataplatform.techtest.service;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.component.impl.ServerImpl;
import com.db.dataplatform.techtest.server.exception.BlockNotFoundException;
import com.db.dataplatform.techtest.server.exception.ChecksumFailureException;
import com.db.dataplatform.techtest.server.exception.HadoopClientException;
import com.db.dataplatform.techtest.server.mapper.ServerMapperConfiguration;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.db.dataplatform.techtest.TestDataHelper.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ServerServiceTests {

    @Mock
    private DataBodyService dataBodyServiceImplMock;

    @Mock
    private RestTemplate restTemplateMock;

    private ModelMapper modelMapper;

    private Server server;

    private int pageNo = 1;
    private int pageSize = 1;

    @Before
    public void setup() {
        ServerMapperConfiguration serverMapperConfiguration = new ServerMapperConfiguration();
        modelMapper = serverMapperConfiguration.createModelMapperBean();
        server = new ServerImpl(dataBodyServiceImplMock, modelMapper, restTemplateMock);
    }

    @Test
    public void shouldSaveDataEnvelopeAsExpected() throws NoSuchAlgorithmException, IOException, HadoopClientException, ChecksumFailureException {

        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject();
        when(restTemplateMock.postForEntity(ServerImpl.HADOOP_URI_PUSHDATA,
                testDataEnvelope, String.class)).thenReturn(ResponseEntity.ok(""));

        server.saveDataEnvelope(testDataEnvelope);

        verify(dataBodyServiceImplMock,
                times(1)).saveDataBody(eq(getExpectedDataBodyEntity(testDataEnvelope)));
        verify(restTemplateMock,
                times(1)).postForEntity(
                eq(ServerImpl.HADOOP_URI_PUSHDATA),
                eq(testDataEnvelope),
                eq(String.class));
    }


    @Test(expected = ChecksumFailureException.class)
    public void shouldNotSaveDataEnvelopeInvalidChecksum() throws NoSuchAlgorithmException, IOException, HadoopClientException, ChecksumFailureException {

        DataEnvelope testDataEnvelope = createTestDataEnvelopeWithInvalidChecksum();
        server.saveDataEnvelope(testDataEnvelope);
        fail("ChecksumFailureException expected");

    }

    @Test(expected = HadoopClientException.class)
    public void shouldThrowExceptionBackendRestFailure() throws NoSuchAlgorithmException, IOException, HadoopClientException, ChecksumFailureException {

        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject();
        when(restTemplateMock.postForEntity(ServerImpl.HADOOP_URI_PUSHDATA,
                testDataEnvelope, String.class)).
                thenReturn(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(""));

        server.saveDataEnvelope(testDataEnvelope);
        fail("Expected HadoopClientException");

    }


    @Test
    public void shouldFetchDataEnvelopeByBlockType() throws NoSuchAlgorithmException, IOException {

        DataBodyEntity dataEnvelopeRes = createTestDataBodyEntity(createTestDataHeaderEntity(Instant.now()));
        Page<DataBodyEntity> companies = Mockito.mock(Page.class);

        when(dataBodyServiceImplMock.getDataByBlockType(eq(BlockTypeEnum.BLOCKTYPEA), eq(PageRequest.of(pageNo,pageSize)))).
                thenReturn(Collections.singletonList(dataEnvelopeRes));
        List<DataEnvelope> data = server.getDataBlocksByType(BlockTypeEnum.BLOCKTYPEA.name(), pageNo, pageSize);
        verify(dataBodyServiceImplMock,
                times(1)).getDataByBlockType(eq(BlockTypeEnum.BLOCKTYPEA), eq(PageRequest.of(pageNo,pageSize)));

        assertThat(data.size() == 1 && data.get(0).equals(dataEnvelopeRes));
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionForUnknownBlockType() throws NoSuchAlgorithmException, IOException {
        List<DataEnvelope> data = server.getDataBlocksByType("some garbage!", pageNo, pageSize);
    }

    @Test(expected = BlockNotFoundException.class)
    public void shouldThrowBlockNotFoundException() throws BlockNotFoundException {
        server.updateBlockType("xx", BlockTypeEnum.BLOCKTYPEA);
    }

    @Test
    public void shouldSaveBlockType() throws BlockNotFoundException {

        DataBodyEntity dataBodyEntity = createTestDataBodyEntity(createTestDataHeaderEntity(Instant.now()));

        when(dataBodyServiceImplMock.getDataByBlockName(dataBodyEntity.getDataHeaderEntity().getName())).
                thenReturn(Optional.of(dataBodyEntity));

        server.updateBlockType(dataBodyEntity.getDataHeaderEntity().getName(), BlockTypeEnum.BLOCKTYPEB);

        verify(dataBodyServiceImplMock,
                times(1)).saveDataBody(eq(dataBodyEntity));

    }


    private DataBodyEntity getExpectedDataBodyEntity(DataEnvelope dataEnvelope) {

        DataBodyEntity expectedDataBodyEntity = modelMapper.map(dataEnvelope.getDataBody(), DataBodyEntity.class);
        expectedDataBodyEntity.setDataHeaderEntity(
                modelMapper.map(dataEnvelope.getDataHeader(), DataHeaderEntity.class));
        return expectedDataBodyEntity;
    }

}
