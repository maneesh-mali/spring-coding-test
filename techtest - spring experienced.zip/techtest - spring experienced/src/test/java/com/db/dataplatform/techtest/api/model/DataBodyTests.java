package com.db.dataplatform.techtest.api.model;

import com.db.dataplatform.techtest.TestDataHelper.*;
import com.db.dataplatform.techtest.server.api.model.DataBody;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static com.db.dataplatform.techtest.TestDataHelper.*;

@RunWith(MockitoJUnitRunner.class)
public class DataBodyTests {

    @Test
    public void assignDataBodyFieldsShouldWorkAsExpected() {
        DataBody dataBody = new DataBody(DUMMY_DATA, DUMMY_MD5_CHECKSUM);

        assertThat(dataBody).isNotNull();
        assertThat(dataBody.getDataBody()).isEqualTo(DUMMY_DATA);
        assertThat(dataBody.getMd5CheckSum()).isEqualTo(DUMMY_MD5_CHECKSUM);

    }
}
