package com.db.dataplatform.techtest.api.controller;

import com.db.dataplatform.techtest.TestDataHelper;
import com.db.dataplatform.techtest.server.api.RestResponseEntityExceptionHandler;
import com.db.dataplatform.techtest.server.api.controller.ServerController;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.exception.BlockNotFoundException;
import com.db.dataplatform.techtest.server.exception.ChecksumFailureException;
import com.db.dataplatform.techtest.server.exception.HadoopClientException;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.util.UriTemplate;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
@ExtendWith(SpringExtension.class)
public class ServerControllerComponentTest {

    public static final String URI_PUSHDATA = "http://localhost:8090/dataserver/pushdata";
    public static final UriTemplate URI_GETDATA = new UriTemplate("http://localhost:8090/dataserver/data/{blockType}");
    public static final UriTemplate URI_PATCHDATA = new UriTemplate("http://localhost:8090/dataserver/update/{name}/{newBlockType}");

    @Mock
    private Server serverMock;

    @Autowired
    WebApplicationContext context;

    private DataEnvelope testDataEnvelope;
    private ObjectMapper objectMapper;
    private MockMvc mockMvc;
    private ServerController serverController;

    @Before
    public void setUp() {
        serverController = new ServerController(serverMock);
        mockMvc = standaloneSetup(serverController).setControllerAdvice(new RestResponseEntityExceptionHandler()).build();
        objectMapper = Jackson2ObjectMapperBuilder
                .json()
                .build();

        testDataEnvelope = TestDataHelper.createTestDataEnvelopeApiObject();
    }

    @Test
    public void testPushDataPostCallWorksAsExpected() throws Exception {

        String testDataEnvelopeJson = objectMapper.writeValueAsString(testDataEnvelope);

        MvcResult mvcResult = mockMvc.perform(post(URI_PUSHDATA)
                .content(testDataEnvelopeJson)
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andReturn();

        boolean result = Boolean.parseBoolean(mvcResult.getResponse().getContentAsString());
        assertThat(result);
    }

    @Test
    public void testPushDataPostCallBackendFailure() throws Exception {

        doThrow(ChecksumFailureException.class).when(serverMock).saveDataEnvelope(any());

        String testDataEnvelopeJson = objectMapper.writeValueAsString(testDataEnvelope);

        MvcResult resultActions = mockMvc.perform(post(URI_PUSHDATA)
                .content(testDataEnvelopeJson)
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(resultActions))
                .andExpect(status().isBadRequest()).andReturn();

        boolean result = Boolean.parseBoolean(resultActions.getResponse().getContentAsString());
        assertThat(!result);

    }

    @Test
    public void testPushDataPostCallBackendException() throws Exception {
        doThrow(HadoopClientException.class).when(serverMock).saveDataEnvelope(any());


        String testDataEnvelopeJson = objectMapper.writeValueAsString(testDataEnvelope);

        MvcResult resultActions = mockMvc.perform(post(URI_PUSHDATA)
                .content(testDataEnvelopeJson)
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(resultActions))
                .andExpect(status().isInternalServerError()).andReturn();

        boolean result = Boolean.parseBoolean(resultActions.getResponse().getContentAsString());
        assertThat(result == false);
    }


    @Test
    public void testGetDataBlocksByTypeWorksAsExpected() throws Exception {

        when(serverMock.getDataBlocksByType(any(String.class), any(), any())).thenReturn(Arrays.asList(testDataEnvelope));

        String blockType = testDataEnvelope.getDataHeader().getBlockType().name();

        MvcResult mvcResult = mockMvc.perform(get(URI_GETDATA.expand(blockType).toString())
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andReturn();

        String response = mvcResult.getResponse().getContentAsString();
        List<DataEnvelope> result = objectMapper.readValue(response, new TypeReference<List<DataEnvelope>>() {
        });
        assertThat(testDataEnvelope.equals(result.get(0)));
    }

    @Test
    public void testUpdateBlockTypeByNameWorksAsExpected() throws Exception {


        when(serverMock.updateBlockType(testDataEnvelope.getDataHeader().getName(), BlockTypeEnum.BLOCKTYPEA)).thenReturn(true);

        String blockName = testDataEnvelope.getDataHeader().getName();

        MvcResult mvcResult = mockMvc.perform(patch(URI_PATCHDATA.expand(blockName, BlockTypeEnum.BLOCKTYPEA.name()).toString())
                .content(objectMapper.writeValueAsString(testDataEnvelope.getDataHeader()))
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andReturn();

        boolean result = Boolean.parseBoolean(mvcResult.getResponse().getContentAsString());
        assertThat(result);
    }

    @Test
    public void testUpdateBlockTypeByNameNotFound() throws Exception {

        String blockName = testDataEnvelope.getDataHeader().getName();

        when(serverMock.updateBlockType(any(), any())).thenThrow(BlockNotFoundException.class);

        MvcResult mvcResult = mockMvc.
                perform(patch(URI_PATCHDATA.expand(testDataEnvelope.getDataHeader().getName(), BlockTypeEnum.BLOCKTYPEB).toString())
                        .content(objectMapper.writeValueAsString(testDataEnvelope.getDataHeader()))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isNotFound())
                .andReturn();

        String res = mvcResult.getResponse().getContentAsString();

        boolean result = Boolean.parseBoolean(mvcResult.getResponse().getContentAsString());

        assertThat(result == false);
    }

    @Test
    @Ignore
    /**
     * todo
     * This test is currently ignore as the mock framework is bypassing the validation
     * This needs to be investigated and fixed!
     */
    public void testUpdateBlockTypeByNameValidationFailure() throws Exception {

        MvcResult mvcResult = mockMvc.
                perform(patch(URI_PATCHDATA.expand("invalidBlockName", BlockTypeEnum.BLOCKTYPEB).toString())
                        )
                .andExpect(status().is4xxClientError())
                .andReturn();

        String res = mvcResult.getResponse().getContentAsString();

        boolean result = Boolean.parseBoolean(mvcResult.getResponse().getContentAsString());

        assertThat(result == false);

    }


}
